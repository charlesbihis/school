// chatClient.c
// the main function of your chatServer

#include <stdio.h>
#include <signal.h> // signal
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>

#include "Socket.h"
#include "Thread.h"
#include "Packet.h"




// The function of the chatClient is to read input from standard
// input, typically the keyboard and write it to the server
// it connected to. At the same time the application is reading from
// the connection to the server and writes whatever is read from the
// network to standard output.
 

// The passed in parameter is the result of  createClientSocket.

void *networkReader(void * param) 
{

	// Add code and declarations here to read information the socket
	// connected to the server and write it to standard output. Upon
	// getting and EOF from the server terminate the application.

	return NULL;
}



// This program takes 3 command line arguments in the following order:
//            1) An string that this client is to be known by (this is
//               not used for this part of the assignment)
//            2) The machine the server is on. This name can be in DNS
//                or dotted IP (i.e. 127.8.9.131) format.
//            3) The port the server is running on
// A sample command line might look like these:
//    chatClient CS213 remote.ugrad.cs.ubc.ca  3678
//    chatClient DA    127.0.0.1    4589
// 


int main (int argc, char* argv[])
{
	// handle SIGPIPE
	if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
		perror("sigHandle, SIGPIPE cannot be handled."); 
		exit(-1);
	}
  
	printf("SIGPIPE set to ignore.%d\n", SIGPIPE);


	// Create a client socket connected to the server. Add the code and
	// declarations below here. 




	// Create and start a thread running the networkReader code to
	// handle the input coming across the network. Add the code and
	// declarations below here. 





	// Once the thread is running have this execution stream loop reading
	// information from standard input and writing it to the server connection.
	//  You may assume a maximum read size of  128 bytes from standard
	// input. Add the code and declarations below here. 
  
	return 0;
}
