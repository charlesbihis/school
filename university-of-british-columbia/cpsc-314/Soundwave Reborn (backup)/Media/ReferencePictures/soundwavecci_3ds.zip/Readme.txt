readme.txt


Author: Dan Huling aka "Ziroc"
Email : ziroc@tgeweb.com


Homepage Since 1993:    [www.tgeweb.com]

Project: v1.0 Soundwave - [G1 Version]
Designed In: Truespace3 v3.1 (If I did it in TS4,  TS3 users couldn't load it)... Works fine in TS 4.0-4.3 though!
Project Start Date Jan 23, 2000
Release Date: Jan 25, 2000


[Copyright Information]

You can use this model all you want, put it up for download, ect.. All I ask is ya give me credit, like a link to my email address (above)
and my Homepage (Also Above) Please Remember, You CANNOT sell this or put it on any type of media for resale! 

[Comments:]

I am into my Transformers Phase again ;-), I am REALLY thinking of making a FULL Animated movie based in the Generation 1 era.
But as you know, it will take time, and to model an entire libarary of transformers (by ONE person) will take a year at the least..
If I DO decide to, you know.. just keep up with the latest new at www.tgeweb.com.

This is our good old friend Soundwave, Enjoy him, render him.. don't BITE him! ;-)
He took around 3 hrs total of work.. easy as pie.. all boxes pretty much.. his head was a bit hard, but its OKAY looking now.
(WHAT WILL BE IN v 1.1?) --> His Missing Rocket Launcher that rests on his shoulder, and his had gun. I'll get v1.1 up in a few days.


Enjoy the model, and if ya use it or anything, drop me some mail, it keeps me going.
(*) This Mesh is Dedicated to My Cat Charly, 1980-1997 - And Chocolate, My new Cat of 3 years!

